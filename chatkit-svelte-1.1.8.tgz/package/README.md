# chatkit-svelte

![](https://img.shields.io/badge/Node.js-24%2B-brightgreen?style=flat-square)
[![npm](https://img.shields.io/npm/v/chatkit-svelte?style=flat-square)](https://www.npmjs.com/package/chatkit-svelte)
[![MIT](https://img.shields.io/npm/l/vitest?style=flat-square)](https://opensource.org/licenses/MIT)
![Svelte](https://img.shields.io/badge/svelte-%23f1413d.svg?style=flat-square&logo=svelte&logoColor=white)

Unofficial Svelte 5 binding for OpenAI's [ChatKit](https://github.com/openai/chatkit-js) Web Component. Updated to Chatkit 1.5.0.

## Installation

```bash
npm install chatkit-svelte @openai/chatkit
# or
pnpm add chatkit-svelte @openai/chatkit
```

## Render

```js
<script lang="ts">
  import Chatkit from 'chatkit-svelte';
  import type { OpenAIChatKit } from '@openai/chatkit';

  let chatkitRef: OpenAIChatKit;
</script>

<Chatkit
    bind:ref={chatkitRef}
    options={{ 
        api: { getClientSecret: async (existing) => "your_client_token" },
        startScreen: {
            greeting: "Welcome to KB!"
        }
    }},
    class="h-[800px] w-[500px]",
    onError={(e) => console.error("Chatkit Error:", e)}
    onResponseStart={() => console.log("Response Began")}
    onResponseEnd={() => console.log("Response Ended")}
    onThreadChange={(e) => console.log("Thread Changed:", e)}
    onThreadLoadStart={(e) => console.log("Thread Load Started:", e.threadId)}
    onLog={(e) => console.log("Chatkit Log:", e)}
    onReady={() => console.log("Chatkit is ready")}
    onEffect={(e) => console.log("Chatkit Fire-n-Forget:", e)}
    onChatkitScriptError={() => console.error("Chatkit script failed to load")}
/>
```

To learn more about the Web Component, please refer the official sources:

- [OpenAI ChatKit JS Guide](https://openai.github.io/chatkit-js/)
- [ChatKit JS GitHub Repository](https://github.com/openai/chatkit-js/blob/main/README.md)

## Component Properties

| Name | Type | Comment |
|------|------|---------|
| `options` | ChatkitOptions | Configuration options for Chatkit. See [ChatkitOptions](https://openai.github.io/chatkit-js/api/openai/chatkit/type-aliases/chatkitoptions/) for details. |
| `class` | string | CSS classes to apply to the Chatkit component. |
| `ref` | OpenAIChatKit | Reference to the underlying Chatkit Web Component instance. |
| `onLog` | (e) => void | Event handler |
| `onError` | (e) => void | Event handler |
| `onResponseStart` | () => void | Event handler |
| `onResponseEnd` | () => void | Event handler |
| `onThreadChange` | (e) => void | Event handler |
| `onThreadLoadStart` | (e) => void | Event handler |
| `onThreadLoadEnd` | (e) => void | Event handler |
| `onReady` | () => void | Event handler |
| `onEffect` | (e) => void | Event handler |
| `onToolChange` | (e) => void | Event handler for composer tool changes. |
| `onChatkitScriptError` | () => void | Event handler called when chatkit JS script could not be loaded. Use this to manage error state. |

<br/>

> About Events, see [here](https://openai.github.io/chatkit-js/api/openai/chatkit/type-aliases/chatkitevents/).

> About Methods, see [here](https://openai.github.io/chatkit-js/guides/methods/). They are accessible using component instance `ref`.
> 

> Valid HTMLAttributes can also be passed to the component.

## Samples

Chatkit with a widget:

<img src="https://realmofbits.dev/images/chatkit_email_draft.jpg" alt="ChatKit Email Draft" style="object-fit: cover;">